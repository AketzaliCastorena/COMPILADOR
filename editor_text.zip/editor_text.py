import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

class CompilerIDE:
    def __init__(self, root):
        # Inicializamos la ventana principal
        self.root = root
        self.root.title("Compilador")
        self.root.geometry("1000x600")
        self.filename = None  # Almacenará el nombre del archivo abierto
        
        self.create_toolbar()  # Creamos la barra de herramientas
        self.create_layout()   # Creamos el layout de la interfaz

    def create_toolbar(self):
        # Creamos la barra de herramientas en la parte superior
        toolbar = tk.Frame(self.root, relief=tk.RAISED, bd=2, bg="#d9d9d9")
        toolbar.pack(side=tk.TOP, fill=tk.X)
        
        # Botón para abrir archivos
        btn_open = tk.Button(toolbar, text="📂 Abrir", command=self.open_file)
        btn_open.pack(side=tk.LEFT, padx=4, pady=2)
        
        # Botón para guardar archivos
        btn_save = tk.Button(toolbar, text="💾 Guardar", command=self.save_file)
        btn_save.pack(side=tk.LEFT, padx=4, pady=2)
        
        # Botón para cerrar el archivo actual
        btn_close = tk.Button(toolbar, text="❌ Cerrar", command=self.close_file)
        btn_close.pack(side=tk.LEFT, padx=4, pady=2)
        
        # Separador visual
        tk.Label(toolbar, text="|").pack(side=tk.LEFT, padx=2)
        
        # Botones para las distintas etapas del análisis
        btn_lexical = tk.Button(toolbar, text="📑 Léxico", command=self.lexical_analysis)
        btn_lexical.pack(side=tk.LEFT, padx=4, pady=2)
        
        btn_syntax = tk.Button(toolbar, text="📜 Sintáctico", command=self.syntax_analysis)
        btn_syntax.pack(side=tk.LEFT, padx=4, pady=2)
        
        btn_semantic = tk.Button(toolbar, text="🔍 Semántico", command=self.semantic_analysis)
        btn_semantic.pack(side=tk.LEFT, padx=4, pady=2)
        
        # Botón para ejecutar la compilación
        btn_compile = tk.Button(toolbar, text="🚀 Compilar", command=self.execute_code)
        btn_compile.pack(side=tk.LEFT, padx=4, pady=2)

    def update_on_key_release(self, event=None):
        # Combina las funciones de actualización de línea y columna
        self.update_line_col(event)
        self.update_line_numbers(event)

    def create_layout(self):
        # Creamos la estructura de la ventana dividida en áreas
        main_frame = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashwidth=5, sashrelief=tk.RAISED)
        main_frame.pack(expand=True, fill=tk.BOTH)
        
        # Área de edición del código
        editor_frame = tk.Frame(main_frame, bg="#cfd8dc")
        
        # Frame para la numeración de líneas
        line_numbers_frame = tk.Frame(editor_frame, width=30, bg="#f0f0f0")
        line_numbers_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        self.line_numbers = tk.Text(line_numbers_frame, width=4, padx=4, pady=5, bg="#f0f0f0", state='disabled')
        self.line_numbers.pack(expand=True, fill=tk.Y)
        
        self.text_area = scrolledtext.ScrolledText(editor_frame, wrap=tk.WORD, bg="#ffffff", fg="#000")
        self.text_area.pack(expand=True, fill=tk.BOTH, padx=5, pady=5)
        
        # Label que muestra la línea y columna actual del cursor
        self.line_col_label = tk.Label(editor_frame, text="Linea: 1 Columna: 1", bg="#cfd8dc", anchor="e")
        self.line_col_label.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Vinculamos la actualización del contador de línea y columna
        # Actualización combinada de eventos de teclado y ratón
        self.text_area.bind("<KeyRelease>", self.update_on_key_release)
        self.text_area.bind("<ButtonRelease-1>", self.update_line_col)
        self.text_area.bind("<MouseWheel>", self.update_line_numbers)
        
        main_frame.add(editor_frame, stretch="always")
        
        # Área para los resultados y errores de los análisis
        results_frame = tk.PanedWindow(main_frame, orient=tk.VERTICAL, sashwidth=5, sashrelief=tk.RAISED)
        
        # Usamos un Notebook (pestañas) para mostrar los resultados de los análisis
        self.tabs = ttk.Notebook(results_frame)
        self.lexical_tab = tk.Text(self.tabs, wrap=tk.WORD, bg="#ffffff")
        self.syntactic_tab = tk.Text(self.tabs, wrap=tk.WORD, bg="#ffffff")
        self.semantic_tab = tk.Text(self.tabs, wrap=tk.WORD, bg="#ffffff")
        self.hash_table_tab = tk.Text(self.tabs, wrap=tk.WORD, bg="#ffffff")
        self.intermediate_code_tab = tk.Text(self.tabs, wrap=tk.WORD, bg="#ffffff")
        
        # Agregamos las pestañas
        self.tabs.add(self.lexical_tab, text="Léxico")
        self.tabs.add(self.syntactic_tab, text="Sintáctico")
        self.tabs.add(self.semantic_tab, text="Semántico")
        self.tabs.add(self.hash_table_tab, text="Hash Table")
        self.tabs.add(self.intermediate_code_tab, text="Código Intermedio")
        
        self.tabs.pack(expand=True, fill=tk.BOTH)
        results_frame.add(self.tabs, stretch="always")
        
        # Área de errores
        error_frame = tk.Frame(results_frame, bg="#eceff1")
        self.error_tabs = ttk.Notebook(error_frame)
        self.lexical_errors = tk.Text(self.error_tabs, wrap=tk.WORD, bg="#ffffff")
        self.syntax_errors = tk.Text(self.error_tabs, wrap=tk.WORD, bg="#ffffff")
        self.semantic_errors = tk.Text(self.error_tabs, wrap=tk.WORD, bg="#ffffff")
        self.results = tk.Text(self.error_tabs, wrap=tk.WORD, bg="#ffffff")
        
        # Agregamos las pestañas de errores
        self.error_tabs.add(self.lexical_errors, text="Errores Léxicos")
        self.error_tabs.add(self.syntax_errors, text="Errores Sintácticos")
        self.error_tabs.add(self.semantic_errors, text="Errores Semánticos")
        self.error_tabs.add(self.results, text="Resultados")
        
        self.error_tabs.pack(expand=True, fill=tk.BOTH)
        error_frame.pack(expand=True, fill=tk.BOTH)
        results_frame.add(error_frame, stretch="always")
        
        main_frame.add(results_frame, stretch="always")
    
    def open_file(self):
        # Abre un archivo y carga su contenido en el área de texto
        self.filename = filedialog.askopenfilename()
        if self.filename:
            with open(self.filename, "r") as file:
                self.text_area.delete(1.0, tk.END)
                self.text_area.insert(tk.END, file.read())
            self.update_line_numbers()
    
    def save_file(self):
        # Guarda el archivo actual si tiene nombre, si no, pide guardar como
        if self.filename:
            with open(self.filename, "w") as file:
                file.write(self.text_area.get(1.0, tk.END))
        else:
            self.save_file_as()
    
    def save_file_as(self):
        # Permite guardar el archivo con un nuevo nombre
        self.filename = filedialog.asksaveasfilename(defaultextension=".txt")
        if self.filename:
            self.save_file()
    
    def close_file(self):
        # Cierra el archivo y limpia el área de texto
        self.text_area.delete(1.0, tk.END)
        self.filename = None
        self.update_line_numbers()
    
    def lexical_analysis(self):
        # Muestra mensaje sobre el análisis léxico en la pestaña correspondiente
        self.lexical_tab.insert(tk.END, "Ejecutando análisis léxico...\n")
    
    def syntax_analysis(self):
        # Muestra mensaje sobre el análisis sintáctico
        self.syntactic_tab.insert(tk.END, "Ejecutando análisis sintáctico...\n")
    
    def semantic_analysis(self):
        # Muestra mensaje sobre el análisis semántico
        self.semantic_tab.insert(tk.END, "Ejecutando análisis semántico...\n")
    
    def execute_code(self):
        # Muestra mensaje de compilación
        messagebox.showinfo("Compilación", "Compilando el código...")

    def update_line_col(self, event=None):
        # Actualiza la posición de la línea y columna del cursor
        line, column = self.text_area.index(tk.INSERT).split(".")
        self.line_col_label.config(text=f"Linea: {line} Columna: {column}")
    
    def update_line_numbers(self, event=None):
        # Actualiza la numeración de líneas
        self.line_numbers.config(state='normal')
        self.line_numbers.delete(1.0, tk.END)
        
        line_count = int(self.text_area.index('end-1c').split('.')[0])
        line_numbers_string = "\n".join(str(i) for i in range(1, line_count + 1))
        
        self.line_numbers.insert(1.0, line_numbers_string)
        self.line_numbers.config(state='disabled')

# Ejecuta la interfaz
if __name__ == "__main__":
    root = tk.Tk()
    app = CompilerIDE(root)
    root.mainloop()
